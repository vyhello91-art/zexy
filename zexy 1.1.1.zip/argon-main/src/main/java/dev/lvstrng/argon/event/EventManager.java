package dev.lvstrng.argon.event;

import dev.lvstrng.argon.Argon;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Objects;
import java.util.concurrent.ConcurrentHashMap;

public final class EventManager {
	private final HashMap<Class<? extends Listener>, ArrayList<PrioritizedListener<? extends Listener>>> listenerMap = new HashMap<>();

	// Sorted listener snapshots. Rebuilt only when a listener is added/removed,
	// instead of copying and sorting on every single event (the old per-tick/per-frame lag).
	private final ConcurrentHashMap<Class<? extends Listener>, ArrayList<? extends Listener>> cache = new ConcurrentHashMap<>();

	private volatile boolean active;

	public static <L extends Listener, E extends Event<L>> void fire(E event) {
		EventManager eventManager = Argon.INSTANCE == null ? null : Argon.INSTANCE.getEventManager();
		if (eventManager != null) {
			eventManager.fireImpl(event);
		}
	}

	@SuppressWarnings("unchecked")
	private <L extends Listener, E extends Event<L>> void fireImpl(E event) {
		// Singleplayer-only: nothing runs on servers, Realms or LAN-opened worlds.
		if (!Argon.isSingleplayer()) {
			if (active) {
				active = false;
				if (Argon.INSTANCE.getModuleManager() != null)
					Argon.INSTANCE.getModuleManager().disableAll();
			}
			return;
		}
		active = true;

		Class<L> listenerType = event.getListenerType();
		ArrayList<L> listeners = (ArrayList<L>) cache.get(listenerType);
		if (listeners == null)
			listeners = rebuild(listenerType);

		if (listeners.isEmpty())
			return;

		event.fire(listeners);
	}

	@SuppressWarnings("unchecked")
	private synchronized <L extends Listener> ArrayList<L> rebuild(Class<L> type) {
		ArrayList<L> out = new ArrayList<>();
		ArrayList<PrioritizedListener<? extends Listener>> raw = listenerMap.get(type);
		if (raw != null) {
			ArrayList<PrioritizedListener<? extends Listener>> sorted = new ArrayList<>(raw);
			sorted.removeIf(Objects::isNull);
			sorted.sort((a, b) -> Integer.compare(b.getPriority(), a.getPriority()));
			for (PrioritizedListener<? extends Listener> l : sorted)
				out.add((L) l.getListener());
		}
		cache.put(type, out);
		return out;
	}

	public <L extends Listener> void add(Class<L> type, L listener) {
		add(type, listener, 0);
	}

	@SuppressWarnings({"unchecked", "rawtypes"})
	public synchronized <L extends Listener> void add(Class<L> type, L listener, int priority) {
		ArrayList<PrioritizedListener<? extends Listener>> listeners = listenerMap.computeIfAbsent(type, k -> new ArrayList<>());
		listeners.add(new PrioritizedListener(listener, priority));
		cache.remove(type);
	}

	public synchronized <L extends Listener> void remove(Class<L> type, L listener) {
		ArrayList<PrioritizedListener<? extends Listener>> listeners = listenerMap.get(type);
		if (listeners != null)
			listeners.removeIf(l -> l.getListener().equals(listener));
		cache.remove(type);
	}

	private static class PrioritizedListener<L extends Listener> {
		private final L listener;
		private final int priority;

		public PrioritizedListener(L listener, int priority) {
			this.listener = listener;
			this.priority = priority;
		}

		public int getPriority() {
			return priority;
		}

		public L getListener() {
			return listener;
		}
	}
}
